-- Creation of users table

create table users
(
	id int primary key not null,
	name text,
	email text,
	number text
);

-- Inserting data into users

INSERT INTO users (id, name, email, "number") VALUES(1, 'Swadhin', 'swadhin@demo.com', '999999999');
INSERT INTO users (id, name, email, "number") VALUES(2, 'Rakesh', 'rakesh@demo.com', '8888888888');
INSERT INTO users (id, name, email, "number") VALUES(123, 'Test User', 'test@demo.com', '7777777777');

-- Creation of orders table

CREATE TABLE orders (
    id TEXT PRIMARY KEY NOT NULL,  
    user_id TEXT,
    product_id TEXT,
    product_name TEXT,
    order_date DATE,
    product_category TEXT,
    order_status TEXT,
    product_price REAL
);

-- Inserting data into orders

insert into orders values 
('ORD_1','1','PRD_1','Samsung','24-Dec-2024','Smartphone','Shipped','15000'),
('ORD_123','123','PRD_2','Xiaomi','01-Feb-2025','Smartphone','Delivered','25500'),
('ORD_1232','123','PRD_23','Lenovo','02-Feb-2025','Laptop','Delivered','25500'),
('ORD_2132','123','PRD_12','Apple','03-Feb-2025','Tablet','Out for Delivery','35000'),
('ORD_1331','123','PRD_16','Boat','04-Feb-2025','Headset','Shipped','3990'),
('ORD_145','2','PRD_123','Samsung','24-Dec-2024','Smartphone','Shipped','15000');

-- Creation of accounts table

create table accounts
(
	id int primary key not null,
	user_id text,
	credited_amount text,
	opening_balance text,
	debited_amount text,
	balance text,
	date DATE
);
-- inserting data into accounts

INSERT into accounts values
('1','123','100000','0','0','100000','2025-01-31'),
('2','123','0','100000','25500','74500','2025-02-01'),
('3','123','50000','74500','35000','89500','2025-02-02'),
('4','123','0','89500','3990','85510','2025-02-03'),
('5','123','0','85510','15000','70510','2025-02-04');

-- Transactional queries:

select * from users where email = 'test@demo.com';
select * from orders where user_id = '123';
SELECT user_id, balance FROM accounts WHERE user_id = '123' ORDER BY date DESC LIMIT 1;