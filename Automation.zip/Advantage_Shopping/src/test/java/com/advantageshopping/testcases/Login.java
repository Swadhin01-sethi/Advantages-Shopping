package com.advantageshopping.testcases;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Login {
	public static Logger logger;

	public static ExtentSparkReporter sparkreport;
	public static ExtentReports reports;
	public static ExtentTest test;

	public static WebDriverWait wait;
	public static ChromeDriver driver;

	@BeforeMethod
	public void start() {

		sparkreport=new ExtentSparkReporter("Advantage.html");
		sparkreport.config().setDocumentTitle("Advantage Shopping Test Report");
		sparkreport.config().setReportName("Automation Test Results");
		reports=new ExtentReports();
		reports.attachReporter(sparkreport);
		test=reports.createTest("login");

		logger=LogManager.getLogger("Advantage_Shopping");
		logger.info("Start the test setup");
		test.log(Status.PASS, "Start the test setup");

		long startTime=System.currentTimeMillis();
		driver=new ChromeDriver();
		wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		driver.get("https://www.advantageonlineshopping.com/");
		driver.manage().window().maximize();		
		logger.info("Browser window maximized.");
		test.log(Status.PASS, "Browser window maximized.");

		long endTime=System.currentTimeMillis();
		long elapsedTimeInSeconds = (endTime - startTime) / 1000;
		System.out.println("Elapsed time in milliseconds: " + elapsedTimeInSeconds);

	}
	@Test(description = "All Test Cases")
	public void login() throws Exception {
		driver.findElement(By.xpath("//*[@id='menuUser']")).click();
		logger.info("Click on the signin button");
		test.log(Status.PASS, "Click on the signin button");
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@name='username']")))).sendKeys("Demo2");
		logger.info("Enter user name");
		test.log(Status.PASS, "Enter user name");
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@name='password']")))).sendKeys("Admin@123");
		logger.info("Enter password");
		test.log(Status.PASS, "Enter password");
		Thread.sleep(10000);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='sign_in_btn']")))).click();
		logger.info("Click on the signin button");
		test.log(Status.PASS, "Click on the signin button");

		Thread.sleep(30000);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("(//*[@id='menuSearch'])[1]")))).click();
		logger.info("Clicked on the search icon");
		test.log(Status.PASS, "Clicked on the search icon");

		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='autoComplete']")))).sendKeys("Laptop");
		Thread.sleep(5000);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("(//*[@class='roboto-regular ng-binding'])[2]")))).click();
		Thread.sleep(3000);
		logger.info("Selected the searched product");
		test.log(Status.PASS, "Selected the searched product");

		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[text()='ADD TO CART']")))).click();
		Thread.sleep(10000);
		logger.info("Added product to cart");
		test.log(Status.PASS, "Added product to cart");


		WebElement element=driver.findElement(By.xpath("//*[@id='menuCart']"));
		Actions ac=new Actions(driver);
		ac.moveToElement(element).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='checkOutPopUp']")).click();
		logger.info("Proceeded to checkout");
		test.log(Status.PASS, "Proceeded to checkout");


		Thread.sleep(2000);
		driver.findElement(By.xpath("(//*[text()='NEXT'])[1]")).click();
		logger.info("Clicked on Next");
		test.log(Status.PASS, "Clicked on Next");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 300)");

		Thread.sleep(1000);
		WebElement username=driver.findElement(By.xpath("//*[@name='safepay_username']"));
		username.clear();
		username.sendKeys("Swadhin");
		logger.info("Entered SafePay username");
		test.log(Status.PASS, "Entered SafePay username");

		Thread.sleep(1000);
		WebElement userpassword=driver.findElement(By.xpath("//*[@name='safepay_password']"));
		userpassword.clear();
		userpassword.sendKeys("Admin@123");
		logger.info("Entered SafePay password");
		test.log(Status.PASS, "Entered SafePay password");

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@name='save_safepay']")).click();
		logger.info("Saved SafePay credentials");
		test.log(Status.PASS, "Saved SafePay credentials");

		Thread.sleep(2000);
		driver.findElement(By.xpath("(//*[text()='PAY NOW'])[1]")).click();
		logger.info("Clicked on Pay Now");
		test.log(Status.PASS, "Clicked on Pay Now");
		Thread.sleep(20000);

		driver.findElement(By.xpath("//*[@id='menuUserSVGPath']")).click();
		Thread.sleep(2000);

	}	
	@AfterMethod
	public void close() {
		driver.findElement(By.xpath("(//*[text()='Sign out'])[2]"));
		logger.info("Signed out successfully");
		test.log(Status.PASS, "Signed out successfully");
		driver.quit();
		reports.flush();
		logger.info("Test execution completed");
		test.log(Status.INFO, "Test execution completed");
	}

}
