Test Case ID: TC_001 : User Login 
----------------------------
Expected Output:User logs in successfully 
Actual output:User able to login successfully

Test Case ID: TC_002 : Product Search
----------------------------
Expected Output:Relevant products displayed  
Actual output:Relevant products are showing

Test Case ID: TC_003 : Add to Cart
----------------------------
Expected Output:Product added to cart  
Actual output:Adding product

Test Case ID: TC_004 : Checkout Process
----------------------------
Expected Output:Order is placed successfully  
Actual output:Order placed


Test Case ID: TC_005 : Logout
----------------------------
Expected Output:User logs out successfully  
Actual output:User able to logout successfully




